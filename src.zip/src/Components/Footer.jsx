const Footer = () => {
    return (
        <>
            <h1 align='center' style={{ backgroundColor: "lightblue" }}>Footer</h1>
        </>
    );
}

export default Footer;